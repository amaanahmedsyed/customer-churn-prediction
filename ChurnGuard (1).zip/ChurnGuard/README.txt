ChurnGuard - Data Science Product Prototype

This project is a churn prediction dashboard built using Python and Streamlit.

How to run:

1. Install required packages:
   pip install streamlit pandas scikit-learn matplotlib plotly

2. Ensure files are in same folder:
   - app.py
   - model.py
   - churn.csv

3. Run the application:
   streamlit run app.py

Features:
- Predicts customer churn using machine learning
- Displays high-risk customers
- Interactive dashboard with filters
- Model evaluation (Accuracy, F1 Score)
- Feature importance analysis
- Basic explanation of predictions

Purpose:
This tool is designed for non-technical users to identify customers at risk and take preventive actions.