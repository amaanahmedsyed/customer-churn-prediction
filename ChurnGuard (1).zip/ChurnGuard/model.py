import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier


def load_data(file):

    # read csv file
    df = pd.read_csv(file)

    # remove customer ID if it exists
    if "customerID" in df.columns:
        df = df.drop("customerID", axis=1)

    # convert churn column to numbers
    if "Churn" in df.columns:
        df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

    # encode categorical columns
    for col in df.columns:
        if df[col].dtype == "object":
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))

    return df


def train_model(df):

    # split features and target
    X = df.drop("Churn", axis=1)
    y = df["Churn"]

    # train test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # create model
    model = RandomForestClassifier()

    # train model
    model.fit(X_train, y_train)

    return model, X, y