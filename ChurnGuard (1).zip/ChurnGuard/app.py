import streamlit as st
import pandas as pd
import time
import plotly.express as px
from model import load_data, train_model
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

st.set_page_config(page_title="ChurnGuard", layout="wide")

# ---------------- HEADER ----------------
st.markdown(
    "<h1 style='text-align: center; color: #4F8BF9;'>ChurnGuard Dashboard</h1>",
    unsafe_allow_html=True
)
st.markdown(
    "<p style='text-align: center;'>AI-powered churn prediction with explainability</p>",
    unsafe_allow_html=True
)

# ---------------- LOAD ----------------
with st.spinner("Loading system..."):
    time.sleep(1.5)
    data = load_data("churn.csv")
    model, X, y = train_model(data)

preds = model.predict(X)
probs = model.predict_proba(X)[:, 1]

data["Prediction"] = preds
data["Churn_Probability"] = probs

# ---------------- SIDEBAR ----------------
st.sidebar.title("Controls")

page = st.sidebar.radio(
    "Navigation",
    ["Overview", "Customer Analysis", "Model Performance", "Insights"]
)

threshold = st.sidebar.slider("Risk Threshold", 0.0, 1.0, 0.7)

# FILTER (important upgrade)
min_prob = st.sidebar.slider("Minimum churn probability", 0.0, 1.0, 0.0)

filtered_data = data[data["Churn_Probability"] >= min_prob]

# ---------------- CARD ----------------
def card(title, value):
    st.markdown(
        f"""
        <div style="background-color:#161B22;
                    padding:15px;
                    border-radius:10px;
                    text-align:center;">
            <h2 style="color:#4F8BF9;">{value}</h2>
            <p>{title}</p>
        </div>
        """,
        unsafe_allow_html=True
    )

# ---------------- OVERVIEW ----------------
if page == "Overview":

    col1, col2, col3 = st.columns(3)

    col1.markdown(card("Total Customers", len(filtered_data)), unsafe_allow_html=True)
    col2.markdown(card("Churn Rate", f"{filtered_data['Prediction'].mean():.2%}"), unsafe_allow_html=True)
    col3.markdown(card("High Risk Users", len(filtered_data[filtered_data["Churn_Probability"] > threshold])), unsafe_allow_html=True)

    st.markdown("### Churn Distribution")

    fig = px.histogram(filtered_data, x="Prediction", color="Prediction")
    st.plotly_chart(fig, use_container_width=True)

# ---------------- CUSTOMER ANALYSIS ----------------
elif page == "Customer Analysis":

    st.subheader("Customer Selection")

    customer_index = st.number_input(
        "Select Customer Index",
        min_value=0,
        max_value=len(filtered_data) - 1,
        value=0
    )

    customer = filtered_data.iloc[customer_index]

    st.write("Customer Data:")
    st.write(customer)

    st.subheader("Prediction")

    st.write("Churn Probability:", round(customer["Churn_Probability"], 2))

    if customer["Churn_Probability"] > threshold:
        st.error("High Risk of Churn")
    else:
        st.success("Low Risk")

    # 🔥 SIMPLE EXPLANATION (important)
    st.subheader("Why this prediction?")

    important_features = X.columns[:3]  # simple explanation

    explanation = []
    for f in important_features:
        explanation.append(f"{f} value = {customer[f]}")

    for e in explanation:
        st.write("-", e)

# ---------------- MODEL ----------------
elif page == "Model Performance":

    acc = accuracy_score(y, preds)
    f1 = f1_score(y, preds)

    col1, col2 = st.columns(2)
    col1.metric("Accuracy", f"{acc:.2f}")
    col2.metric("F1 Score", f"{f1:.2f}")

    cm = confusion_matrix(y, preds)

    fig = px.imshow(cm, text_auto=True, title="Confusion Matrix")
    st.plotly_chart(fig, use_container_width=True)

# ---------------- INSIGHTS ----------------
elif page == "Insights":

    importance = model.feature_importances_

    df_imp = pd.DataFrame({
        "Feature": X.columns,
        "Importance": importance
    }).sort_values(by="Importance", ascending=False)

    fig = px.bar(
        df_imp.head(10),
        x="Importance",
        y="Feature",
        orientation="h"
    )

    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Filtered Dataset")
    st.dataframe(filtered_data, use_container_width=True)